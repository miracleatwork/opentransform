package com.monolith.legacy;

public class ClassA<T> {

	public T value;
	public ClassA()
	{
		
	}
	public ClassA(T value)
	{
		this.value = value; 
	}
	public  T getValue()
	{
		return value;
	}
	public void setValue(T t)
	{
		this.value = t;
	}
}
