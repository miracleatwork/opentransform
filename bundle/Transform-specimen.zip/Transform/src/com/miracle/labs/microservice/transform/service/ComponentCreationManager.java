package com.miracle.labs.microservice.transform.service;

import java.io.IOException;

import com.miracle.labs.microservice.transform.model.Attributes;

public class ComponentCreationManager {

	protected Attributes attributes;
	
	
	
	
	public ComponentCreationManager(Attributes attributes) {
		super();
		this.attributes = attributes;
	}

	
	
	
	/**
	 * Copy extension classes like RESTClient
	 */
	
	public void copyExtensionClasses()
	{
		
	}
	
	public void addRESTWrapper()
	{
		
	}
}
